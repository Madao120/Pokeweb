import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import "./index.css";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    {/* Banner superior */}
    <header className="app-banner app-banner-top">
      {/* Tornillo + rejilla izquierda */}
      <div className="banner-side banner-side-left">
        <div className="banner-screw" />
        <div className="banner-grid">
          <span />
          <span />
          <span />
        </div>
      </div>

      {/* Centro vacío — aquí irán los ojos en el paso siguiente */}
      <div className="banner-center" />

      {/* Rejilla + tornillo derecha */}
      <div className="banner-side banner-side-right">
        <div className="banner-grid">
          <span />
          <span />
          <span />
        </div>
        <div className="banner-screw" />
      </div>
    </header>

    <BrowserRouter>
      <main className="app-content">
        <App />
      </main>
    </BrowserRouter>

    {/* Banner inferior — imágenes en paso 5 */}
    <footer className="app-banner app-banner-bottom" />
  </StrictMode>,
);
